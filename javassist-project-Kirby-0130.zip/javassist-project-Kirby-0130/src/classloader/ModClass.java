package classloader;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Scanner;

import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtField;
import javassist.CtMethod;
import javassist.Modifier;
import javassist.NotFoundException;

public class ModClass extends ClassLoader {
	static final String SEP = File.separator;
	static String WORK_DIR = System.getProperty("user.dir");
	static String INPUT_DIR = WORK_DIR + SEP + "classfiles";
	private ClassPool pool;
	public String insertFieldName;
	
	public static void main(String[] args) throws Throwable {
		Scanner sc = new Scanner(System.in);
		String[] list;
		boolean check = false;
		
		do {
			System.out.println("Please enter one class names and one field name (ComponentApp, f1 or ServiceApp, f2):");
			String input = sc.nextLine();
			list = input.split(",");
			for (int i = 0; i < list.length; i++) {
				list[i] = list[i].trim();
			}

			if (list.length != 2) {
				System.out.println("[WRN] Invalid Input size!!");
				for (int i = 0; i < list.length; i++) {
					list[i] = null;
				}
			} else {
				String className = list[0];
				String fieldName = list[1];
				
				ModClass mc = new ModClass(fieldName);
				Class<?> c = mc.findClass("target." + className);
				Method m = c.getDeclaredMethod("main", new Class[] {String[].class});
				m.invoke(null, new Object[] {list});
				check = true;
			}
		} while (!check);
	}

	public ModClass(String fieldName) throws NotFoundException  {
		pool = ClassPool.getDefault();
		pool.insertClassPath(INPUT_DIR);
		insertFieldName = fieldName;
	}

	protected Class<?> findClass(String name) throws ClassNotFoundException {
		try {
			CtClass cc = pool.get(name);
			CtField f = new CtField(CtClass.doubleType, insertFieldName, cc);
			f.setModifiers(Modifier.PUBLIC);
			cc.addField(f, CtField.Initializer.constant(0.0));
			
			byte[] b = cc.toBytecode();
			return defineClass(name, b, 0, b.length);
		} catch (NotFoundException e) {
			throw new ClassNotFoundException();
		} catch (IOException e) {
			throw new ClassNotFoundException();
		} catch (CannotCompileException e) {
			throw new ClassNotFoundException();
		}
	}
}